import validator from './validator.js';

console.log(validator);
